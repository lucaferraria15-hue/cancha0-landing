import LandingCancha0 from './LandingCancha0'

function App() {
  return <LandingCancha0 />
}

export default App
